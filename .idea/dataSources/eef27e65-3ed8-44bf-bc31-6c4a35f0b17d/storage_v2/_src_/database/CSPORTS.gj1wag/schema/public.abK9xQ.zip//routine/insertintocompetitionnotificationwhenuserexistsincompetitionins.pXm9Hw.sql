create function insertintocompetitionnotificationwhenuserexistsincompetitionins()
  returns trigger
language plpgsql
as $$
DECLARE
  a competition%ROWTYPE;
  b competition%ROWTYPE;
BEGIN
  FOR a IN
    SELECT * FROM competition WHERE host_id = new.account_id
  LOOP
    INSERT INTO competition_notification(activity_id, host_id, invitee_id, seen, competition_id) VALUES (new.activity_id, new.account_id, a.invitee_id, FALSE, concat(a.competition_id, a.invitee_id));
  END LOOP;
  FOR b IN
    SELECT * From competition WHERE invitee_id = new.account_id
  LOOP
    INSERT INTO competition_notification(activity_id, host_id, invitee_id, seen, competition_id) VALUES (new.activity_id, new.account_id, b.host_id, FALSE , concat(b.competition_id, b.host_id));
  END LOOP;
  RETURN new;
END;
$$;

alter function insertintocompetitionnotificationwhenuserexistsincompetitionins()
  owner to admin;

