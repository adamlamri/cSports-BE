create function unaccent_replace(x text)
  returns text
language plpgsql
as $$
declare
	codau text; kdau text; r text;
begin
	codau='áàảãạâấầẩẫậăắằẳẵặđéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵÁÀẢÃẠÂẤẦẨẪẬĂẮẰẲẴẶĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ';
	kdau ='aaaaaaaaaaaaaaaaadeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyyAAAAAAAAAAAAAAAAADEEEEEEEEEEEIIIIIOOOOOOOOOOOOOOOOOUUUUUUUUUUUYYYYY';
	r=x;
	for i in 0..length(codau)
	loop
		r=replace(r,substr(codau,i,1),substr(kdau,i,1));
	end loop;
	return r;
end;
$$;

alter function unaccent_replace(text)
  owner to admin;

