create function updatecompetitionnotificationwhenuserexistsincompetitionupdatea()
  returns trigger
language plpgsql
as $$
BEGIN
  UPDATE competition_notification SET seen = FALSE WHERE activity_id = new.activity_id;
  RETURN new;
END;
$$;

alter function updatecompetitionnotificationwhenuserexistsincompetitionupdatea()
  owner to admin;

