create function deletecompetitionnotificationwhencompetitionisdeleted()
  returns trigger
language plpgsql
as $$
BEGIN
  DELETE FROM competition_notification WHERE host_id = old.host_id AND invitee_id = old.invitee_id;
  DELETE FROM competition_notification WHERE host_id = old.invitee_id AND invitee_id = old.host_id;
  RETURN old;
END;
$$;

alter function deletecompetitionnotificationwhencompetitionisdeleted()
  owner to admin;

